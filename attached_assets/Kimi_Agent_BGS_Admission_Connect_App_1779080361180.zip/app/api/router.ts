import { createRouter } from "./middleware";
import { applicationsRouter } from "./routes/applications";
import { staffRouter } from "./routes/staff";
import { settingsRouter } from "./routes/settings";
import { publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  applications: applicationsRouter,
  staff: staffRouter,
  settings: settingsRouter,
});

export type AppRouter = typeof appRouter;
