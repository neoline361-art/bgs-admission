import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { applications } from "@db/schema";
import { eq, like, and, desc } from "drizzle-orm";

function generateAppId(id: number): string {
  return `BGS-2026-${String(id).padStart(4, "0")}`;
}

export const applicationsRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        studentName: z.string().min(1),
        parentName: z.string().min(1),
        phone: z.string().regex(/^\d{10}$/),
        village: z.string().min(1),
        interestedClass: z.enum(["1st PUC", "2nd PUC"]),
        stream: z.enum(["Science", "Commerce"]),
        previousSchool: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Find first active teacher to assign
      const { staff } = await import("@db/schema");
      const teachers = await db
        .select()
        .from(staff)
        .where(and(eq(staff.role, "teacher"), eq(staff.active, 1)));

      const assignedTo =
        teachers.length > 0
          ? teachers[Math.floor(Math.random() * teachers.length)].staffId
          : "T001";

      const result = await db.insert(applications).values({
        applicationId: "TEMP",
        studentName: input.studentName,
        parentName: input.parentName,
        phone: input.phone,
        village: input.village,
        interestedClass: input.interestedClass,
        stream: input.stream,
        previousSchool: input.previousSchool || null,
        notes: input.notes || null,
        status: "new",
        assignedTo,
      });

      const insertId = Number(result[0].insertId);
      const appId = generateAppId(insertId);

      await db
        .update(applications)
        .set({ applicationId: appId })
        .where(eq(applications.id, insertId));

      return { id: insertId, applicationId: appId };
    }),

  list: publicQuery
    .input(
      z
        .object({
          status: z.string().optional(),
          village: z.string().optional(),
          assignedTo: z.string().optional(),
          interestedClass: z.string().optional(),
          stream: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      let query = db.select().from(applications).orderBy(desc(applications.createdAt));

      const conditions = [];
      if (input?.status) conditions.push(eq(applications.status, input.status as any));
      if (input?.village) conditions.push(eq(applications.village, input.village));
      if (input?.assignedTo) conditions.push(eq(applications.assignedTo, input.assignedTo));
      if (input?.interestedClass) conditions.push(eq(applications.interestedClass, input.interestedClass));
      if (input?.stream) conditions.push(eq(applications.stream, input.stream));

      if (conditions.length > 0) {
        return db
          .select()
          .from(applications)
          .where(and(...conditions))
          .orderBy(desc(applications.createdAt));
      }

      return db.select().from(applications).orderBy(desc(applications.createdAt));
    }),

  getById: publicQuery
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const results = await db
        .select()
        .from(applications)
        .where(eq(applications.applicationId, input.id));
      return results[0] || null;
    }),

  getByPhone: publicQuery
    .input(z.object({ phone: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const results = await db
        .select()
        .from(applications)
        .where(eq(applications.phone, input.phone))
        .orderBy(desc(applications.createdAt));
      return results[0] || null;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.string(),
        status: z
          .enum(["new", "contacted", "meeting_fixed", "confirmed", "archived"])
          .optional(),
        notes: z.string().optional(),
        meetingDate: z.string().optional(),
        meetingTime: z.string().optional(),
        assignedTo: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...updates } = input;
      const updateData: any = {};
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.notes !== undefined) updateData.notes = updates.notes;
      if (updates.meetingDate !== undefined) updateData.meetingDate = updates.meetingDate;
      if (updates.meetingTime !== undefined) updateData.meetingTime = updates.meetingTime;
      if (updates.assignedTo !== undefined) updateData.assignedTo = updates.assignedTo;

      await db
        .update(applications)
        .set(updateData)
        .where(eq(applications.applicationId, id));

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .delete(applications)
        .where(eq(applications.applicationId, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(applications);
    return {
      total: all.length,
      new: all.filter((a) => a.status === "new").length,
      contacted: all.filter((a) => a.status === "contacted").length,
      meetingFixed: all.filter((a) => a.status === "meeting_fixed").length,
      confirmed: all.filter((a) => a.status === "confirmed").length,
      archived: all.filter((a) => a.status === "archived").length,
    };
  }),
});
