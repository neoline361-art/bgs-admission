import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { settings } from "@db/schema";
import { eq } from "drizzle-orm";

export const settingsRouter = createRouter({
  getAll: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(settings);
  }),

  get: publicQuery
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const results = await db
        .select()
        .from(settings)
        .where(eq(settings.key, input.key));
      return results[0]?.value || null;
    }),

  set: publicQuery
    .input(z.object({ key: z.string(), value: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(settings)
        .where(eq(settings.key, input.key));

      if (existing.length > 0) {
        await db
          .update(settings)
          .set({ value: input.value, updatedAt: new Date() })
          .where(eq(settings.key, input.key));
      } else {
        await db.insert(settings).values({
          key: input.key,
          value: input.value,
        });
      }
      return { success: true };
    }),

  setMany: publicQuery
    .input(z.record(z.string()))
    .mutation(async ({ input }) => {
      const db = getDb();
      for (const [key, value] of Object.entries(input)) {
        const existing = await db
          .select()
          .from(settings)
          .where(eq(settings.key, key));

        if (existing.length > 0) {
          await db
            .update(settings)
            .set({ value, updatedAt: new Date() })
            .where(eq(settings.key, key));
        } else {
          await db.insert(settings).values({ key, value });
        }
      }
      return { success: true };
    }),
});
