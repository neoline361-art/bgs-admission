import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { staff } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const staffRouter = createRouter({
  login: publicQuery
    .input(
      z.object({
        staffId: z.string(),
        pin: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const results = await db
        .select()
        .from(staff)
        .where(
          and(
            eq(staff.staffId, input.staffId),
            eq(staff.pin, input.pin),
            eq(staff.active, 1)
          )
        );

      const member = results[0];
      if (!member) {
        return { success: false, error: "Invalid credentials" };
      }

      return {
        success: true,
        user: {
          id: member.staffId,
          nameEn: member.nameEn,
          nameKn: member.nameKn,
          role: member.role,
          phone: member.phone,
        },
      };
    }),

  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(staff).orderBy(staff.staffId);
  }),

  create: publicQuery
    .input(
      z.object({
        staffId: z.string(),
        nameEn: z.string(),
        nameKn: z.string().optional(),
        pin: z.string(),
        role: z.enum(["teacher", "office", "admin"]),
        phone: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(staff).values({
        staffId: input.staffId,
        nameEn: input.nameEn,
        nameKn: input.nameKn || null,
        pin: input.pin,
        role: input.role,
        phone: input.phone || null,
      });
      return { success: true };
    }),

  update: publicQuery
    .input(
      z.object({
        staffId: z.string(),
        nameEn: z.string().optional(),
        nameKn: z.string().optional(),
        pin: z.string().optional(),
        phone: z.string().optional(),
        active: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { staffId, ...updates } = input;
      await db.update(staff).set(updates).where(eq(staff.staffId, staffId));
      return { success: true };
    }),
});
