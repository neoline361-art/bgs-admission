import { useLanguage } from "@/context/LanguageContext";
import { getStatusColor } from "@/lib/utils";

export default function StatusBadge({ status }: { status: string }) {
  const { t } = useLanguage();

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(status)}`}>
      {t(status) || status}
    </span>
  );
}
