import { useLanguage } from "@/context/LanguageContext";

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-800 text-slate-300 py-4 mt-auto no-print">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <p className="text-xs">&copy; 2026 {t("collegeName")} - {t("collegeCode")} - {t("allRightsReserved")}</p>
        <p className="text-xs text-slate-400 mt-1">{t("poweredBy")}</p>
      </div>
    </footer>
  );
}
