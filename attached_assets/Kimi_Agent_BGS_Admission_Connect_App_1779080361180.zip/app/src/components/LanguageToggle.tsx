import { Languages } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <button
      onClick={toggleLanguage}
      className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-white shadow-md border border-gray-200 rounded-full px-4 py-2 text-sm font-medium hover:bg-gray-50 active:scale-95 transition-all no-print"
      aria-label="Toggle language"
    >
      <Languages size={18} className="text-blue-800" />
      <span className="text-blue-800 font-semibold">{language === "en" ? "Kannada" : "English"}</span>
    </button>
  );
}
