import { Link, useLocation } from "react-router-dom";
import { GraduationCap, LogOut, ArrowLeft } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";

export default function Navbar() {
  const { t } = useLanguage();
  const { isAuthenticated, user, logout } = useAuth();
  const location = useLocation();

  const isDashboard = ["/teacher", "/office", "/admin"].some((p) => location.pathname.startsWith(p));

  return (
    <nav className="bg-blue-800 text-white shadow-md no-print">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GraduationCap size={28} className="text-white" />
          <div>
            <h1 className="text-sm font-bold leading-tight">{t("appName")}</h1>
            <p className="text-xs text-blue-200 leading-tight">{t("appNameSub")}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isDashboard && (
            <button onClick={() => window.print()}
              className="text-xs bg-blue-700 hover:bg-blue-600 px-3 py-1.5 rounded transition-colors">{t("print")}</button>
          )}
          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              <span className="text-xs text-blue-200 hidden sm:inline">{user?.nameEn}</span>
              <button onClick={logout}
                className="flex items-center gap-1 text-xs bg-red-600 hover:bg-red-500 px-3 py-1.5 rounded transition-colors">
                <LogOut size={14} /><span className="hidden sm:inline">{t("logout")}</span>
              </button>
            </div>
          ) : (
            <Link to="/" className="flex items-center gap-1 text-xs bg-blue-700 hover:bg-blue-600 px-3 py-1.5 rounded transition-colors">
              <ArrowLeft size={14} /><span className="hidden sm:inline">{t("home")}</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
