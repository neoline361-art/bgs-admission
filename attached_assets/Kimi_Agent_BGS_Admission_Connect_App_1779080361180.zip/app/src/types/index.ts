// Shared types for the application
