import { Link, useParams } from "react-router-dom";
import { CheckCircle, FileText, Home } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";

export default function SuccessPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();

  const { data: student } = trpc.applications.getById.useQuery(
    { id: id || "" },
    { enabled: !!id }
  );

  if (!student) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">{t("loading")}</p>
          <Link to="/" className="text-blue-800 underline mt-2 inline-block">{t("backToHome")}</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-8 max-w-md w-full text-center">
        <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={40} className="text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-1">{t("applicationReceived")}</h1>
        <p className="text-sm text-gray-500 mb-4">{t("applicationReceivedSub")}</p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <p className="text-xs text-blue-600 font-medium uppercase tracking-wide">{t("applicationId")}</p>
          <p className="text-2xl font-bold text-blue-800 font-mono mt-1">{student.applicationId}</p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-6">
          <p className="text-sm text-green-700 flex items-center justify-center gap-2">
            <CheckCircle size={16} />{t("whatsappConfirmation")}
          </p>
        </div>

        <div className="space-y-3">
          <Link to={`/application/${student.applicationId}`}
            className="flex items-center justify-center gap-2 w-full bg-blue-800 text-white rounded-lg py-3 font-semibold hover:bg-blue-700 transition-colors">
            <FileText size={18} />{t("viewMyApplication")}
          </Link>
          <Link to="/"
            className="flex items-center justify-center gap-2 w-full bg-gray-100 text-gray-700 rounded-lg py-3 font-semibold hover:bg-gray-200 transition-colors">
            <Home size={18} />{t("backToHome")}
          </Link>
        </div>
      </div>
    </div>
  );
}
