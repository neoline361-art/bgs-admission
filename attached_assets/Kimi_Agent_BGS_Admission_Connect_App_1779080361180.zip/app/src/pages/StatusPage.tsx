import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ArrowLeft, FileText, Phone, User, GraduationCap, MapPin } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import StatusBadge from "@/components/StatusBadge";

export default function StatusPage() {
  const { t } = useLanguage();
  const [phone, setPhone] = useState("");
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState("");

  const { data: student, isLoading } = trpc.applications.getByPhone.useQuery(
    { phone: phone.trim() },
    { enabled: searched && phone.length === 10 }
  );

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!/^\d{10}$/.test(phone.trim())) {
      setError(t("invalidPhone"));
      setSearched(true);
      return;
    }
    setSearched(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-5">
          <h1 className="text-xl font-bold text-gray-900 mb-1">{t("statusCheck")}</h1>
          <p className="text-xs text-gray-500 mb-5">{t("enterPhone")}</p>

          <form onSubmit={handleCheck} className="flex gap-2 mb-6">
            <input type="tel" value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder={t("phoneNumber")} pattern="[0-9]{10}" inputMode="numeric"
              className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <button type="submit" className="bg-blue-800 text-white rounded-lg px-5 py-3 hover:bg-blue-700 transition-colors">
              <Search size={20} />
            </button>
          </form>

          {error && <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4"><p className="text-sm text-red-700">{error}</p></div>}

          {isLoading && <div className="text-center py-8"><p className="text-gray-500">{t("loading")}</p></div>}

          {searched && !isLoading && !student && !error && (
            <div className="text-center py-8">
              <FileText size={40} className="mx-auto text-gray-300 mb-2" />
              <p className="text-gray-500">{t("noApplicationFound")}</p>
            </div>
          )}

          {student && (
            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-gray-500">{t("applicationId")}</p>
                <p className="text-sm font-mono font-semibold text-blue-800">{student.applicationId}</p>
              </div>
              <div className="flex items-center gap-2"><User size={16} className="text-blue-800" />
                <p className="font-semibold text-gray-900">{student.studentName}</p></div>
              <div className="flex items-center gap-2"><Phone size={16} className="text-green-600" />
                <p className="text-sm text-gray-700">{student.phone}</p></div>
              <div className="flex items-center gap-2"><MapPin size={16} className="text-red-500" />
                <p className="text-sm text-gray-700">{student.village}</p></div>
              <div className="flex items-center gap-2"><GraduationCap size={16} className="text-blue-800" />
                <p className="text-sm text-gray-700">{student.interestedClass} - {student.stream}</p></div>
              <div className="pt-2 border-t border-gray-100">
                <p className="text-xs text-gray-500 mb-1">{t("status")}</p>
                <StatusBadge status={student.status} />
              </div>
              {(student.meetingDate || student.meetingTime) && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="text-xs text-amber-700">{t("meetingDetails")}</p>
                  <p className="text-sm font-semibold text-amber-900">{student.meetingDate} {student.meetingTime}</p>
                </div>
              )}
              <Link to={`/application/${student.applicationId}`}
                className="block text-center text-blue-800 text-sm font-medium mt-3 hover:underline">
                {t("viewDetails")} &rarr;
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
