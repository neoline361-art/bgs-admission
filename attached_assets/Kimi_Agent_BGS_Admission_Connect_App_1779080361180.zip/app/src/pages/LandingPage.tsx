import { Link } from "react-router-dom";
import { UserPlus, LogIn, QrCode, FileText, Phone, MapPin, GraduationCap, BookOpen, FlaskConical, Monitor } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";

export default function LandingPage() {
  const { t, language } = useLanguage();
  const { data: stats } = trpc.applications.stats.useQuery();

  return (
    <div className="min-h-screen flex flex-col">
      <div className="bg-blue-800 text-white pb-16 pt-8 px-4">
        <div className="max-w-lg mx-auto text-center">
          <GraduationCap size={56} className="mx-auto mb-4 text-white" />
          <h1 className="text-2xl font-bold mb-2">{t("appName")}</h1>
          <p className="text-blue-200 text-sm mb-1">{t("appNameSub")}</p>
          <p className="text-blue-300 text-xs">{t("collegeCode")}</p>
          {stats && stats.total > 0 && (
            <div className="mt-4 inline-flex items-center gap-4 bg-white/10 rounded-full px-4 py-2">
              <span className="text-xs text-blue-200">{stats.total} {language === "kn" ? "ಅರ್ಜಿಗಳು" : "Applications"}</span>
              <span className="text-xs text-green-300">{stats.confirmed} {language === "kn" ? "ದೃಢೀಕೃತ" : "Confirmed"}</span>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-lg mx-auto w-full px-4 -mt-10">
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 space-y-4">
          <Link to="/apply"
            className="flex items-center gap-4 w-full bg-blue-800 text-white rounded-xl px-6 py-5 hover:bg-blue-700 active:scale-[0.98] transition-all shadow-md">
            <div className="bg-white/20 rounded-full p-3"><UserPlus size={28} /></div>
            <div className="text-left">
              <p className="font-semibold text-lg">{t("applyForAdmission")}</p>
              <p className="text-blue-200 text-xs">{language === "kn" ? "ಪ್ರವೇಶಕ್ಕೆ ಅರ್ಜಿ ಸಲ್ಲಿಸಿ" : "Apply for Admission"}</p>
            </div>
          </Link>

          <Link to="/staff/login"
            className="flex items-center gap-4 w-full bg-slate-100 text-slate-800 rounded-xl px-6 py-5 hover:bg-slate-200 active:scale-[0.98] transition-all border border-slate-200">
            <div className="bg-slate-300 rounded-full p-3"><LogIn size={28} className="text-slate-700" /></div>
            <div className="text-left">
              <p className="font-semibold text-lg">{t("staffLogin")}</p>
              <p className="text-slate-500 text-xs">{language === "kn" ? "ಸಿಬ್ಬಂದಿ ಲಾಗಿನ್" : "Staff Login"}</p>
            </div>
          </Link>
        </div>

        <div className="mt-8">
          <h2 className="text-lg font-bold text-gray-800 mb-4 text-center">{t("howItWorks")}</h2>
          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: QrCode, step: t("step1"), desc: t("step1Desc"), color: "text-blue-800", bg: "bg-blue-100" },
              { icon: FileText, step: t("step2"), desc: t("step2Desc"), color: "text-green-800", bg: "bg-green-100" },
              { icon: UserPlus, step: t("step3"), desc: t("step3Desc"), color: "text-amber-800", bg: "bg-amber-100" },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className={`${item.bg} rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-2`}>
                  <item.icon size={28} className={item.color} />
                </div>
                <p className="text-xs font-medium text-gray-700">{item.step}</p>
                <p className="text-[10px] text-gray-500 mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 mb-8">
          <h2 className="text-lg font-bold text-gray-800 mb-4 text-center">{t("streams")}</h2>
          <div className="space-y-3">
            {[
              { icon: FlaskConical, title: t("scienceStream"), desc: t("science"), bg: "bg-blue-100", color: "text-blue-800" },
              { icon: Monitor, title: t("commerceStream"), desc: t("commerce"), bg: "bg-green-100", color: "text-green-800" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white rounded-lg p-3 border border-gray-200 shadow-sm">
                <div className={`${item.bg} rounded-lg p-2`}><item.icon size={20} className={item.color} /></div>
                <div>
                  <p className="text-sm font-semibold text-gray-800">{item.title}</p>
                  <p className="text-xs text-gray-500">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-8">
          {[
            { to: "/status", icon: FileText, label: t("statusCheck"), color: "text-blue-800" },
            { to: "/fees", icon: Phone, label: t("fees"), color: "text-green-700" },
            { to: "/contact", icon: MapPin, label: t("contact"), color: "text-red-600" },
          ].map((item, i) => (
            <Link key={i} to={item.to} className="text-center bg-white rounded-lg p-3 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
              <item.icon size={24} className={`mx-auto ${item.color} mb-1`} />
              <p className="text-xs font-medium text-gray-700">{item.label}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
