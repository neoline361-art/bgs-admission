import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { LogIn, ArrowLeft, Shield, RefreshCw } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { trpc } from "@/providers/trpc";

function generateCaptcha(): string {
  return String(Math.floor(1000 + Math.random() * 9000));
}

export default function StaffLoginPage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const { login, isAuthenticated, user } = useAuth();
  const { data: staffList } = trpc.staff.list.useQuery();

  const [nameId, setNameId] = useState("");
  const [pin, setPin] = useState("");
  const [captchaValue, setCaptchaValue] = useState("");
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === "teacher") navigate("/teacher");
      else if (user.role === "office") navigate("/office");
      else if (user.role === "admin") navigate("/admin");
    }
  }, [isAuthenticated, user, navigate]);

  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha());
    setCaptchaValue("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!nameId) { setError(t("selectName")); return; }
    if (!pin || !/^\d{4}$/.test(pin)) { setError(t("invalidPin")); return; }
    if (captchaValue !== captcha) { setError(t("invalidCaptcha")); refreshCaptcha(); return; }

    setLoading(true);
    const success = await login(nameId, pin);
    setLoading(false);
    if (!success) {
      setError(t("loginFailed"));
      refreshCaptcha();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
          <div className="text-center mb-6">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
              <Shield size={32} className="text-blue-800" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">{t("staffLogin")}</h1>
            <p className="text-xs text-gray-500 mt-1">{t("collegeName")}</p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("name")} *</label>
              <select value={nameId} onChange={(e) => setNameId(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">{t("selectName")}</option>
                {staffList?.map((s) => (
                  <option key={s.staffId} value={s.staffId}>
                    {language === "kn" && s.nameKn ? s.nameKn : s.nameEn} ({t(s.role)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("pin")} *</label>
              <input type="password" value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                maxLength={4} inputMode="numeric"
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 tracking-widest"
                placeholder="••••" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("captcha")} *</label>
              <div className="flex items-center gap-3">
                <div className="bg-gray-800 border border-gray-600 rounded-lg px-6 py-3 select-none flex-shrink-0 min-w-[140px] text-center">
                  <p className="text-2xl font-bold text-white tracking-[0.3em]" style={{ letterSpacing: "0.5em", fontFamily: "monospace" }}>
                    {captcha}
                  </p>
                </div>
                <input type="text" value={captchaValue}
                  onChange={(e) => setCaptchaValue(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  inputMode="numeric" maxLength={4}
                  className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder={t("captchaPlaceholder")} />
                <button type="button" onClick={refreshCaptcha}
                  className="p-3 text-gray-500 hover:text-blue-800 transition-colors">
                  <RefreshCw size={20} />
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-800 text-white rounded-lg py-3 text-base font-semibold hover:bg-blue-700 active:scale-[0.98] transition-all shadow-md disabled:opacity-50">
              <LogIn size={20} />
              {loading ? "..." : t("login")}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
