import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Send, ArrowLeft } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import { villages } from "@/data/villages";

const CLASSES = ["1st PUC", "2nd PUC"] as const;
const STREAMS = ["Science", "Commerce"] as const;

export default function ApplyPage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const createMutation = trpc.applications.create.useMutation();

  const [formData, setFormData] = useState({
    studentName: "",
    parentName: "",
    phone: "",
    village: "",
    interestedClass: "" as "1st PUC" | "2nd PUC" | "",
    stream: "" as "Science" | "Commerce" | "",
    previousSchool: "",
    notes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.studentName.trim()) newErrors.studentName = t("fillAllFields");
    if (!formData.parentName.trim()) newErrors.parentName = t("fillAllFields");
    if (!/^\d{10}$/.test(formData.phone.trim())) newErrors.phone = t("invalidPhone");
    if (!formData.village) newErrors.village = t("fillAllFields");
    if (!formData.interestedClass) newErrors.interestedClass = t("fillAllFields");
    if (!formData.stream) newErrors.stream = t("fillAllFields");
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    try {
      const result = await createMutation.mutateAsync({
        studentName: formData.studentName,
        parentName: formData.parentName,
        phone: formData.phone,
        village: formData.village,
        interestedClass: formData.interestedClass as "1st PUC" | "2nd PUC",
        stream: formData.stream as "Science" | "Commerce",
        previousSchool: formData.previousSchool || undefined,
        notes: formData.notes || undefined,
      });
      navigate(`/success/${result.applicationId}`);
    } catch {
      alert(t("errorOccurred"));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-5">
          <h1 className="text-xl font-bold text-gray-900 mb-1">{t("applicationForm")}</h1>
          <p className="text-xs text-gray-500 mb-5">{t("appNameSub")}</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("studentName")} *</label>
              <input type="text" name="studentName" value={formData.studentName} onChange={handleChange}
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.studentName ? "border-red-500" : "border-gray-300"}`}
                placeholder={t("studentName")} />
              {errors.studentName && <p className="text-xs text-red-500 mt-1">{errors.studentName}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("parentName")} *</label>
              <input type="text" name="parentName" value={formData.parentName} onChange={handleChange}
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.parentName ? "border-red-500" : "border-gray-300"}`}
                placeholder={t("parentName")} />
              {errors.parentName && <p className="text-xs text-red-500 mt-1">{errors.parentName}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("phoneNumber")} *</label>
              <input type="tel" name="phone" value={formData.phone} onChange={handleChange}
                pattern="[0-9]{10}" maxLength={10} inputMode="numeric"
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.phone ? "border-red-500" : "border-gray-300"}`}
                placeholder={t("phoneDigitsOnly")} />
              {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("village")} *</label>
              <select name="village" value={formData.village} onChange={handleChange}
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.village ? "border-red-500" : "border-gray-300"}`}>
                <option value="">{t("selectVillage")}</option>
                {villages.map((v) => (
                  <option key={v.en} value={v.kn}>{language === "kn" ? v.kn : v.en}</option>
                ))}
              </select>
              {errors.village && <p className="text-xs text-red-500 mt-1">{errors.village}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("interestedClass")} *</label>
              <select name="interestedClass" value={formData.interestedClass} onChange={handleChange}
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.interestedClass ? "border-red-500" : "border-gray-300"}`}>
                <option value="">{t("selectClass")}</option>
                {CLASSES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              {errors.interestedClass && <p className="text-xs text-red-500 mt-1">{errors.interestedClass}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("stream")} *</label>
              <select name="stream" value={formData.stream} onChange={handleChange}
                className={`w-full border rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.stream ? "border-red-500" : "border-gray-300"}`}>
                <option value="">{t("selectStream")}</option>
                {STREAMS.map((s) => (
                  <option key={s} value={s}>{t(s.toLowerCase() + "Stream")}</option>
                ))}
              </select>
              {errors.stream && <p className="text-xs text-red-500 mt-1">{errors.stream}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("previousSchool")}</label>
              <input type="text" name="previousSchool" value={formData.previousSchool} onChange={handleChange}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={t("previousSchool")} />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t("anyNotes")}</label>
              <textarea name="notes" value={formData.notes} onChange={handleChange} rows={3}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                placeholder={t("anyNotes")} />
            </div>

            <button type="submit" disabled={createMutation.isPending}
              className="w-full flex items-center justify-center gap-2 bg-blue-800 text-white rounded-lg py-4 text-lg font-semibold hover:bg-blue-700 active:scale-[0.98] transition-all shadow-md disabled:opacity-50">
              <Send size={20} />
              {createMutation.isPending ? "Submitting..." : t("submitApplication")}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
