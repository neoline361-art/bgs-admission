import { Link } from "react-router-dom";
import { ArrowLeft, IndianRupee, GraduationCap, CreditCard, Wallet, Landmark } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";

export default function FeePage() {
  const { t } = useLanguage();
  const { data: settingsList } = trpc.settings.getAll.useQuery();
  const getSetting = (key: string) => settingsList?.find((s) => s.key === key)?.value || "";

  const feeData = [
    { item: t("admissionFee"), amount: parseInt(getSetting("admissionFee")) || 500 },
    { item: t("tuitionFee"), amount: parseInt(getSetting("tuitionFee")) || 12000 },
    { item: t("labFee"), amount: parseInt(getSetting("labFee")) || 2000 },
    { item: t("libraryFee"), amount: parseInt(getSetting("libraryFee")) || 500 },
    { item: t("examFee"), amount: parseInt(getSetting("examFee")) || 1500 },
    { item: t("sportsFee"), amount: parseInt(getSetting("sportsFee")) || 500 },
    { item: t("developmentFee"), amount: parseInt(getSetting("developmentFee")) || 1000 },
  ];
  const total = feeData.reduce((sum, f) => sum + f.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-5">
            <IndianRupee size={24} className="text-green-700" />
            <h1 className="text-xl font-bold text-gray-900">{t("fees")}</h1>
          </div>
          <div className="overflow-hidden rounded-lg border border-gray-200 mb-6">
            <table className="w-full text-sm">
              <thead className="bg-blue-50">
                <tr><th className="text-left p-3 font-semibold text-gray-700">{t("feeStructure")}</th><th className="text-right p-3 font-semibold text-gray-700">{t("feeAmount")}</th></tr>
              </thead>
              <tbody>
                {feeData.map((fee, i) => (
                  <tr key={i} className="border-t border-gray-100">
                    <td className="p-3 text-gray-700">{fee.item}</td>
                    <td className="p-3 text-right font-medium text-gray-900">Rs.{fee.amount.toLocaleString("en-IN")}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-blue-200 bg-blue-50">
                  <td className="p-3 font-bold text-blue-800">{t("totalFees")}</td>
                  <td className="p-3 text-right font-bold text-blue-800">Rs.{total.toLocaleString("en-IN")}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-green-800 mb-2 flex items-center gap-2"><GraduationCap size={18} />{t("scholarships")}</h3>
            <ul className="text-sm text-green-700 space-y-1">
              <li>Merit Scholarship - 90% above: 50% fee waiver</li>
              <li>SC/ST Scholarship: Full tuition fee waiver</li>
              <li>Sports Quota: 25% fee concession</li>
              <li>Sibling Discount: 10% for second child</li>
            </ul>
          </div>
          <div className="space-y-3">
            <h3 className="font-semibold text-gray-800">{t("paymentMethods")}</h3>
            {[
              { icon: Wallet, text: t("cash"), color: "text-green-600" },
              { icon: CreditCard, text: t("upi"), color: "text-blue-600" },
              { icon: Landmark, text: t("bankTransfer"), color: "text-purple-600" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white border border-gray-200 rounded-lg p-3">
                <item.icon size={20} className={item.color} />
                <p className="text-sm text-gray-700">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
