import { Link } from "react-router-dom";
import { ArrowLeft, Phone, MessageCircle, MapPin, Clock, ExternalLink } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import { getTelUrl, getWhatsAppUrl } from "@/lib/utils";

export default function ContactPage() {
  const { t, language } = useLanguage();
  const { data: settingsList } = trpc.settings.getAll.useQuery();
  const getSetting = (key: string) => settingsList?.find((s) => s.key === key)?.value || "";

  const collegePhone = getSetting("collegePhone") || "9876500000";
  const collegeWhatsapp = getSetting("collegeWhatsapp") || "9876500000";
  const address = getSetting("collegeAddress") || t("collegeAddress");
  const officeHours = getSetting("officeHours") || "9:00 AM - 4:30 PM";

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-5">
          <h1 className="text-xl font-bold text-gray-900 mb-5">{t("contactUs")}</h1>
          <div className="space-y-4">
            <a href={getTelUrl(collegePhone)} className="flex items-center gap-4 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
              <div className="bg-green-600 rounded-full p-3"><Phone size={24} className="text-white" /></div>
              <div>
                <p className="text-xs text-green-700 font-medium">{t("phone")}</p>
                <p className="text-lg font-semibold text-gray-900">{collegePhone}</p>
                <p className="text-xs text-gray-500">{t("clickToCall")}</p>
              </div>
            </a>
            <a href={getWhatsAppUrl(collegeWhatsapp, `Namaskara, BGS PU College bagge hechu maahiti beku.`)} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
              <div className="bg-green-500 rounded-full p-3"><MessageCircle size={24} className="text-white" /></div>
              <div>
                <p className="text-xs text-green-700 font-medium">WhatsApp</p>
                <p className="text-lg font-semibold text-gray-900">{collegeWhatsapp}</p>
                <p className="text-xs text-gray-500">{t("clickToWhatsApp")}</p>
              </div>
            </a>
            <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-lg">
              <div className="bg-blue-800 rounded-full p-3 flex-shrink-0"><MapPin size={24} className="text-white" /></div>
              <div className="flex-1">
                <p className="text-xs text-blue-700 font-medium">{t("address")}</p>
                <p className="text-sm font-semibold text-gray-900 mt-1">{t("collegeName")}</p>
                <p className="text-sm text-gray-700">{address}</p>
                <button onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`, "_blank")}
                  className="mt-2 flex items-center gap-1 text-xs text-blue-800 font-medium hover:underline">
                  <ExternalLink size={12} />{t("getDirections")}
                </button>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 bg-amber-50 rounded-lg">
              <div className="bg-amber-600 rounded-full p-3 flex-shrink-0"><Clock size={24} className="text-white" /></div>
              <div>
                <p className="text-xs text-amber-700 font-medium">{t("hours")}</p>
                <div className="mt-1 space-y-1">
                  <p className="text-sm text-gray-800"><span className="font-medium">{t("mondayToSaturday")}:</span> {officeHours}</p>
                  <p className="text-sm text-red-600 font-medium">{t("sundayClosed")}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-6 rounded-lg overflow-hidden border border-gray-200">
            <iframe title="BGS PU College Location" width="100%" height="250" style={{ border: 0 }}
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3883.0!2d77.87!3d13.39!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDIzJzI0LjAiTiA3N8KwNTInMTIuMCJF!5e0!3m2!1sen!2sin!4v1"
              allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          </div>
        </div>
      </div>
    </div>
  );
}
