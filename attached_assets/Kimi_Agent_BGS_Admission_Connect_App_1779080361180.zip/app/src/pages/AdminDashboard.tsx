import { useState } from "react";
import { Navigate } from "react-router-dom";
import { BarChart3, Download, Users, Settings, QrCode, TrendingUp, MapPin, BookOpen, Clock, Save } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import { villages } from "@/data/villages";
import { exportToCSV } from "@/lib/utils";
import StatusBadge from "@/components/StatusBadge";

export default function AdminDashboard() {
  const { isAuthenticated, hasRole, user } = useAuth();
  const { t, language } = useLanguage();
  const utils = trpc.useUtils();

  const [activeTab, setActiveTab] = useState("overview");

  const { data: allApps, isLoading } = trpc.applications.list.useQuery();
  const { data: stats } = trpc.applications.stats.useQuery();
  const { data: staffList } = trpc.staff.list.useQuery();
  const { data: settingsList } = trpc.settings.getAll.useQuery();

  const updateMutation = trpc.applications.update.useMutation({
    onSuccess: () => utils.applications.list.invalidate(),
  });
  const setSetting = trpc.settings.set.useMutation({
    onSuccess: () => utils.settings.getAll.invalidate(),
  });
  const setManySettings = trpc.settings.setMany.useMutation({
    onSuccess: () => utils.settings.getAll.invalidate(),
  });
  const updateStaff = trpc.staff.update.useMutation({
    onSuccess: () => utils.staff.list.invalidate(),
  });

  if (!isAuthenticated) return <Navigate to="/staff/login" replace />;
  if (!hasRole(["admin"])) return <Navigate to="/" replace />;

  const getSetting = (key: string) => settingsList?.find((s) => s.key === key)?.value || "";

  const [editSettings, setEditSettings] = useState<Record<string, string>>({});

  const handleSettingChange = (key: string, value: string) => {
    setEditSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveSettings = () => {
    setManySettings.mutate(editSettings);
    setEditSettings({});
  };

  const totalStudents = allApps?.length || 0;
  const confirmedCount = allApps?.filter((s) => s.status === "confirmed").length || 0;
  const meetingFixedCount = allApps?.filter((s) => s.status === "meeting_fixed").length || 0;

  const villageCounts: Record<string, number> = {};
  allApps?.forEach((s) => { villageCounts[s.village] = (villageCounts[s.village] || 0) + 1; });
  const villageBreakdown = Object.entries(villageCounts).sort((a, b) => b[1] - a[1]);

  const streamCounts: Record<string, number> = {};
  allApps?.filter((s) => s.stream).forEach((s) => { streamCounts[s.stream] = (streamCounts[s.stream] || 0) + 1; });
  const totalStreams = Object.values(streamCounts).reduce((a, b) => a + b, 0) || 1;
  const streamBreakdown = Object.entries(streamCounts).sort((a, b) => b[1] - a[1]);

  const teacherStats = (staffList || []).filter((s) => s.role === "teacher").map((teacher) => {
    const teacherStudents = (allApps || []).filter((s) => s.assignedTo === teacher.staffId);
    return {
      ...teacher,
      total: teacherStudents.length,
      confirmed: teacherStudents.filter((s) => s.status === "confirmed").length,
      meeting_fixed: teacherStudents.filter((s) => s.status === "meeting_fixed").length,
    };
  });

  const today = new Date().toISOString().split("T")[0];
  const todaysMeetings = (allApps || []).filter(
    (s) => s.meetingDate === today && s.status === "meeting_fixed"
  );

  const handleExportCSV = () => {
    const exportData = (allApps || []).map((s) => ({
      "Application ID": s.applicationId,
      "Student Name": s.studentName,
      "Parent Name": s.parentName,
      Phone: s.phone,
      Village: s.village,
      Class: s.interestedClass,
      Stream: s.stream,
      Status: s.status,
      "Assigned To": s.assignedTo,
      "Meeting Date": s.meetingDate || "",
      "Meeting Time": s.meetingTime || "",
      Notes: s.notes || "",
      "Submitted On": new Date(s.createdAt).toLocaleDateString(),
    }));
    exportToCSV(exportData, `bgs-full-report-${new Date().toISOString().split("T")[0]}.csv`);
  };

  if (isLoading) return <div className="min-h-screen bg-gray-100 flex items-center justify-center"><p>{t("loading")}</p></div>;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 size={20} className="text-blue-800" />
            <h1 className="font-bold text-gray-900">{t("admin")}</h1>
            <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">{t("admin")}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => {
                const canvas = document.createElement("canvas");
                canvas.width = 300; canvas.height = 300;
                const ctx = canvas.getContext("2d")!;
                ctx.fillStyle = "white"; ctx.fillRect(0, 0, 300, 300);
                ctx.fillStyle = "black";
                for (let i = 0; i < 25; i++) for (let j = 0; j < 25; j++) if (Math.random() > 0.5) ctx.fillRect(20 + i * 10, 20 + j * 10, 10, 10);
                ctx.fillRect(20, 20, 70, 10); ctx.fillRect(20, 20, 10, 70); ctx.fillRect(80, 20, 10, 70); ctx.fillRect(20, 80, 70, 10);
                ctx.fillRect(200, 20, 70, 10); ctx.fillRect(200, 20, 10, 70); ctx.fillRect(260, 20, 10, 70); ctx.fillRect(200, 80, 70, 10);
                ctx.fillRect(20, 200, 70, 10); ctx.fillRect(20, 200, 10, 70); ctx.fillRect(80, 200, 10, 70); ctx.fillRect(20, 260, 70, 10);
                const link = document.createElement("a");
                link.download = "bgs-qr-code.png"; link.href = canvas.toDataURL(); link.click();
              }}
              className="text-xs flex items-center gap-1 bg-purple-100 hover:bg-purple-200 text-purple-800 px-3 py-1.5 rounded transition-colors">
              <QrCode size={14} />{t("generateQR")}
            </button>
            <button onClick={handleExportCSV}
              className="text-xs flex items-center gap-1 bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1.5 rounded transition-colors">
              <Download size={14} />{t("exportCSV")}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex gap-2 overflow-x-auto">
          {[
            { key: "overview", label: t("myStats"), icon: TrendingUp },
            { key: "villages", label: t("villageBreakdown"), icon: MapPin },
            { key: "streams", label: t("streamDemand"), icon: BookOpen },
            { key: "teachers", label: t("teacherPerformance"), icon: Users },
            { key: "meetings", label: t("todaysMeetings"), icon: Clock },
            { key: "settings", label: t("settings"), icon: Settings },
          ].map((tab) => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.key ? "bg-blue-800 text-white" : "bg-white text-gray-700 hover:bg-gray-50 border border-gray-200"
              }`}>
              <tab.icon size={14} />{tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pb-8">
        {activeTab === "overview" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: t("totalApplications"), value: totalStudents, color: "bg-blue-800 text-white" },
                { label: t("confirmed"), value: confirmedCount, color: "bg-green-600 text-white" },
                { label: t("meetingFixed"), value: meetingFixedCount, color: "bg-amber-500 text-white" },
                { label: t("archived"), value: stats?.archived || 0, color: "bg-red-500 text-white" },
              ].map((stat, i) => (
                <div key={i} className={`${stat.color} rounded-xl p-4 text-center shadow-sm`}>
                  <p className="text-3xl font-bold">{stat.value}</p>
                  <p className="text-xs opacity-90 mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <h2 className="font-semibold text-gray-900 mb-3">{t("status")} {t("filterBy")}</h2>
              <div className="space-y-2">
                {["new", "contacted", "meeting_fixed", "confirmed", "archived"].map((status) => {
                  const count = allApps?.filter((a) => a.status === status).length || 0;
                  const pct = totalStudents > 0 ? Math.round((count / totalStudents) * 100) : 0;
                  return (
                    <div key={status} className="flex items-center gap-3">
                      <span className="text-xs font-medium w-24 capitalize">{status.replace("_", " ")}</span>
                      <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                        <div className="h-full bg-blue-800 rounded-full flex items-center justify-end pr-2 transition-all" style={{ width: `${pct}%` }}>
                          {pct > 10 && <span className="text-[10px] text-white font-medium">{pct}%</span>}
                        </div>
                      </div>
                      <span className="text-xs font-medium w-8 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === "villages" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h2 className="font-semibold text-gray-900 mb-3">{t("villageBreakdown")}</h2>
            <div className="space-y-2">
              {villageBreakdown.map(([village, count]) => (
                <div key={village} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                  <span className="text-sm">{village}</span>
                  <div className="flex items-center gap-3">
                    <div className="bg-gray-100 rounded-full h-2 w-32 overflow-hidden">
                      <div className="h-full bg-blue-800 rounded-full" style={{ width: `${(count / totalStudents) * 100}%` }} />
                    </div>
                    <span className="text-sm font-medium w-8 text-right">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "streams" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h2 className="font-semibold text-gray-900 mb-3">{t("streamDemand")}</h2>
            <div className="space-y-3">
              {streamBreakdown.map(([stream, count]) => {
                const pct = Math.round((count / totalStreams) * 100);
                return (
                  <div key={stream} className="flex items-center gap-3">
                    <span className="text-sm font-medium w-20">{stream}</span>
                    <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                      <div className="h-full bg-blue-800 rounded-full flex items-center justify-end pr-2" style={{ width: `${pct}%` }}>
                        {pct > 10 && <span className="text-[10px] text-white font-medium">{pct}%</span>}
                      </div>
                    </div>
                    <span className="text-sm w-8 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === "teachers" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h2 className="font-semibold text-gray-900 mb-3">{t("teacherPerformance")}</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-gray-50">
                  <th className="text-left p-3">{t("name")}</th>
                  <th className="text-center p-3">{t("totalApplications")}</th>
                  <th className="text-center p-3">{t("confirmed")}</th>
                  <th className="text-center p-3">{t("meetingFixed")}</th>
                  <th className="text-center p-3">%</th>
                </tr></thead>
                <tbody>
                  {teacherStats.map((teacher) => {
                    const rate = teacher.total > 0 ? Math.round((teacher.confirmed / teacher.total) * 100) : 0;
                    return (
                      <tr key={teacher.staffId} className="border-t border-gray-100 hover:bg-gray-50">
                        <td className="p-3">
                          <p className="font-medium">{language === "kn" && teacher.nameKn ? teacher.nameKn : teacher.nameEn}</p>
                          <p className="text-xs text-gray-500">{teacher.phone}</p>
                        </td>
                        <td className="p-3 text-center">{teacher.total}</td>
                        <td className="p-3 text-center text-green-600 font-medium">{teacher.confirmed}</td>
                        <td className="p-3 text-center text-amber-600 font-medium">{teacher.meeting_fixed}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            rate >= 50 ? "bg-green-100 text-green-800" : rate >= 30 ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"
                          }`}>{rate}%</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "meetings" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h2 className="font-semibold text-gray-900 mb-3">{t("todaysMeetings")} ({todaysMeetings.length})</h2>
            {todaysMeetings.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Clock size={40} className="mx-auto mb-2 text-gray-300" />
                <p>{t("noMeetingsToday")}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {todaysMeetings.map((m) => (
                  <div key={m.applicationId} className="flex items-center justify-between p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{m.studentName}</p>
                      <p className="text-xs text-gray-500">{m.village} - {m.interestedClass} {m.stream}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-amber-800">{m.meetingTime}</p>
                      <StatusBadge status={m.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "settings" && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-gray-900">{t("collegeInfo")}</h2>
                <button onClick={handleSaveSettings}
                  className="flex items-center gap-1 text-xs bg-green-600 text-white px-3 py-1.5 rounded hover:bg-green-700 transition-colors">
                  <Save size={14} />{t("save")}
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: "collegeNameEn", label: "College Name (English)" },
                  { key: "collegeNameKn", label: "College Name (Kannada)" },
                  { key: "collegeAddress", label: "Address" },
                  { key: "collegeCode", label: "College Code" },
                  { key: "collegePhone", label: "Phone" },
                  { key: "collegeWhatsapp", label: "WhatsApp" },
                  { key: "officeHours", label: "Office Hours" },
                ].map((field) => (
                  <div key={field.key}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{field.label}</label>
                    <input
                      type="text"
                      defaultValue={getSetting(field.key)}
                      onChange={(e) => handleSettingChange(field.key, e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-gray-900">{t("feeStructure")}</h2>
                <button onClick={handleSaveSettings}
                  className="flex items-center gap-1 text-xs bg-green-600 text-white px-3 py-1.5 rounded hover:bg-green-700 transition-colors">
                  <Save size={14} />{t("save")}
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { key: "admissionFee", label: t("admissionFee") },
                  { key: "tuitionFee", label: t("tuitionFee") },
                  { key: "labFee", label: t("labFee") },
                  { key: "libraryFee", label: t("libraryFee") },
                  { key: "examFee", label: t("examFee") },
                  { key: "sportsFee", label: t("sportsFee") },
                  { key: "developmentFee", label: t("developmentFee") },
                ].map((field) => (
                  <div key={field.key}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{field.label}</label>
                    <input
                      type="text"
                      defaultValue={getSetting(field.key)}
                      onChange={(e) => handleSettingChange(field.key, e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <h2 className="font-semibold text-gray-900 mb-3">{t("manageTeachers")}</h2>
              <div className="space-y-3">
                {(staffList || []).map((s) => (
                  <div key={s.staffId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{language === "kn" && s.nameKn ? s.nameKn : s.nameEn}</p>
                      <p className="text-xs text-gray-500 capitalize">{s.role} - PIN: {s.pin} - {s.phone}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${s.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {s.active ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
