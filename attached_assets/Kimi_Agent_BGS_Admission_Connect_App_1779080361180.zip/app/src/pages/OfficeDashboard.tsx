import { useState } from "react";
import { Navigate } from "react-router-dom";
import { BarChart3, Download, Filter, Phone, MessageCircle, Calendar, Check, Archive } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import { villages } from "@/data/villages";
import StatusBadge from "@/components/StatusBadge";
import { exportToCSV, getStatusColor, getWhatsAppUrl, getTelUrl, maskPhone, TIME_SLOTS } from "@/lib/utils";

export default function OfficeDashboard() {
  const { isAuthenticated, hasRole, user } = useAuth();
  const { t, language } = useLanguage();
  const utils = trpc.useUtils();

  const { data: allApps, isLoading } = trpc.applications.list.useQuery();
  const { data: staffList } = trpc.staff.list.useQuery();
  const updateMutation = trpc.applications.update.useMutation({
    onSuccess: () => {
      utils.applications.list.invalidate();
      utils.applications.stats.invalidate();
    },
  });

  const [filterVillage, setFilterVillage] = useState("");
  const [filterClass, setFilterClass] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterTeacher, setFilterTeacher] = useState("");
  const [viewMode, setViewMode] = useState<"kanban" | "list">("kanban");
  const [meetingModal, setMeetingModal] = useState<any>(null);
  const [meetingDate, setMeetingDate] = useState("");
  const [meetingTime, setMeetingTime] = useState("");

  if (!isAuthenticated) return <Navigate to="/staff/login" replace />;
  if (!hasRole(["office", "admin"])) return <Navigate to="/" replace />;

  const filteredStudents = (allApps || []).filter((s) => {
    if (filterVillage && s.village !== filterVillage) return false;
    if (filterClass && s.interestedClass !== filterClass) return false;
    if (filterStatus && s.status !== filterStatus) return false;
    if (filterTeacher && s.assignedTo !== filterTeacher) return false;
    return true;
  });

  const classes = [...new Set((allApps || []).map((s) => s.interestedClass))];

  const stats = {
    total: filteredStudents.length,
    new: filteredStudents.filter((s) => s.status === "new").length,
    contacted: filteredStudents.filter((s) => s.status === "contacted").length,
    meeting_fixed: filteredStudents.filter((s) => s.status === "meeting_fixed").length,
    confirmed: filteredStudents.filter((s) => s.status === "confirmed").length,
    archived: filteredStudents.filter((s) => s.status === "archived").length,
  };

  const handleExportCSV = () => {
    const exportData = filteredStudents.map((s) => ({
      "Application ID": s.applicationId,
      "Student Name": s.studentName,
      "Parent Name": s.parentName,
      Phone: s.phone,
      Village: s.village,
      Class: s.interestedClass,
      Stream: s.stream,
      Status: s.status,
      "Assigned To": s.assignedTo,
      "Meeting Date": s.meetingDate || "",
      "Meeting Time": s.meetingTime || "",
      Notes: s.notes || "",
      "Previous School": s.previousSchool || "",
      "Submitted On": new Date(s.createdAt).toLocaleDateString(),
    }));
    exportToCSV(exportData, `bgs-applications-${new Date().toISOString().split("T")[0]}.csv`);
  };

  const handleReassign = (studentId: string, teacherId: string) => {
    updateMutation.mutate({ id: studentId, assignedTo: teacherId });
  };

  const STATUS_COLUMNS = [
    { key: "new", label: "New", color: "bg-slate-50" },
    { key: "contacted", label: "Contacted", color: "bg-blue-50" },
    { key: "meeting_fixed", label: "Meeting Fixed", color: "bg-amber-50" },
    { key: "confirmed", label: "Confirmed", color: "bg-green-50" },
    { key: "archived", label: "Archived", color: "bg-red-50" },
  ];

  const handleContact = (s: any) => {
    const msg = `Namaskara ${s.parentName}, BGS PU College. ${s.studentName}'s application ${s.applicationId} received. We will call you for campus visit. When are you free?`;
    window.open(getWhatsAppUrl(s.phone, msg), "_blank");
    updateMutation.mutate({ id: s.applicationId, status: "contacted" });
  };

  const handleFixMeeting = () => {
    if (!meetingModal || !meetingDate || !meetingTime) return;
    updateMutation.mutate({
      id: meetingModal.appId,
      status: "meeting_fixed",
      meetingDate,
      meetingTime,
    });
    setMeetingModal(null);
    setMeetingDate("");
    setMeetingTime("");
  };

  const handleConfirm = (s: any) => {
    updateMutation.mutate({ id: s.applicationId, status: "confirmed" });
  };

  const handleArchive = (s: any) => {
    updateMutation.mutate({ id: s.applicationId, status: "archived" });
  };

  if (isLoading) return <div className="min-h-screen bg-gray-100 flex items-center justify-center"><p>{t("loading")}</p></div>;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-3 no-print">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <BarChart3 size={20} className="text-blue-800" />
              <h1 className="font-bold text-gray-900">{t("office")}</h1>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setViewMode(viewMode === "kanban" ? "list" : "kanban")}
                className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded transition-colors">
                {viewMode === "kanban" ? "List View" : "Kanban View"}
              </button>
              <button onClick={handleExportCSV}
                className="text-xs flex items-center gap-1 bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1.5 rounded transition-colors">
                <Download size={14} />{t("exportCSV")}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <Filter size={16} className="text-gray-400" />
            <span className="text-xs text-gray-500">{t("filterBy")}:</span>
            <select value={filterVillage} onChange={(e) => setFilterVillage(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1">
              <option value="">{t("byVillage")}</option>
              {villages.map((v) => (<option key={v.en} value={v.kn}>{language === "kn" ? v.kn : v.en}</option>))}
            </select>
            <select value={filterClass} onChange={(e) => setFilterClass(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1">
              <option value="">{t("byClass")}</option>
              {classes.map((c) => (<option key={c} value={c}>{c}</option>))}
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1">
              <option value="">{t("status")}</option>
              {STATUS_COLUMNS.map((c) => (<option key={c.key} value={c.key}>{c.label}</option>))}
            </select>
            <select value={filterTeacher} onChange={(e) => setFilterTeacher(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1">
              <option value="">{t("byTeacher")}</option>
              {staffList?.filter((s) => s.role === "teacher").map((tch) => (
                <option key={tch.staffId} value={tch.staffId}>{tch.nameEn}</option>
              ))}
            </select>
            <button onClick={() => { setFilterVillage(""); setFilterClass(""); setFilterStatus(""); setFilterTeacher(""); }}
              className="text-xs text-blue-800 hover:underline">{t("all")}</button>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {[
              { label: t("totalApplications"), value: stats.total, color: "bg-gray-100 text-gray-800" },
              { label: t("new"), value: stats.new, color: "bg-slate-100 text-slate-800" },
              { label: t("contacted"), value: stats.contacted, color: "bg-blue-100 text-blue-800" },
              { label: t("meetingFixed"), value: stats.meeting_fixed, color: "bg-amber-100 text-amber-800" },
              { label: t("confirmed"), value: stats.confirmed, color: "bg-green-100 text-green-800" },
              { label: t("archived"), value: stats.archived, color: "bg-red-100 text-red-800" },
            ].map((stat, i) => (
              <div key={i} className={`${stat.color} rounded-lg p-2 text-center`}>
                <p className="text-lg font-bold">{stat.value}</p>
                <p className="text-[10px] font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-7xl mx-auto">
          {viewMode === "kanban" ? (
            <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
              {STATUS_COLUMNS.map((col) => (
                <div key={col.key} className="snap-start flex-shrink-0 w-full sm:w-72 md:w-80">
                  <div className={`${col.color} rounded-lg border border-gray-200`}>
                    <div className="px-3 py-2 border-b border-gray-200 flex items-center justify-between">
                      <h3 className="font-semibold text-sm text-gray-800">{col.label}</h3>
                      <span className="bg-white text-xs font-medium px-2 py-0.5 rounded-full text-gray-600 border border-gray-200">
                        {filteredStudents.filter((s) => s.status === col.key).length}
                      </span>
                    </div>
                    <div className="p-2 space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto">
                      {filteredStudents.filter((s) => s.status === col.key).map((student) => (
                        <div key={student.applicationId} className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-semibold text-gray-900 text-sm">{student.studentName}</h3>
                            <StatusBadge status={student.status} />
                          </div>
                          <p className="text-xs text-gray-500 mb-1">{student.interestedClass} - {student.stream}</p>
                          <p className="text-xs text-gray-600">{maskPhone(student.phone)} | {student.village}</p>
                          {student.assignedTo && (
                            <p className="text-xs text-gray-400 mt-1">Assigned: {student.assignedTo}</p>
                          )}
                          <div className="flex flex-wrap gap-1 mt-2">
                            <a href={getTelUrl(student.phone)} className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px]">
                              <Phone size={10} />{t("call")}</a>
                            <button onClick={() => handleContact(student)} className="inline-flex items-center gap-1 bg-green-600 text-white px-2 py-0.5 rounded text-[10px]">
                              <MessageCircle size={10} />{t("whatsapp")}</button>
                            {student.status !== "meeting_fixed" && student.status !== "confirmed" && (
                              <button onClick={() => setMeetingModal({ appId: student.applicationId })}
                                className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px]">
                                <Calendar size={10} />{t("fixMeeting")}</button>
                            )}
                            {student.status === "meeting_fixed" && (
                              <button onClick={() => handleConfirm(student)} className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px]">
                                <Check size={10} />{t("confirm")}</button>
                            )}
                            {student.status !== "archived" && (
                              <button onClick={() => handleArchive(student)} className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px]">
                                <Archive size={10} />{t("archive")}</button>
                            )}
                          </div>
                          <select value={student.assignedTo || ""}
                            onChange={(e) => handleReassign(student.applicationId, e.target.value)}
                            className="mt-2 text-[10px] border border-gray-300 rounded px-1 py-0.5 w-full">
                            <option value="">{t("assignedTeacher")}</option>
                            {staffList?.filter((s) => s.role === "teacher").map((tch) => (
                              <option key={tch.staffId} value={tch.staffId}>{tch.nameEn}</option>
                            ))}
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("studentName")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("phoneNumber")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("village")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("interestedClass")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("status")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("teacher")}</th>
                      <th className="text-left p-3 font-semibold text-gray-700">{t("actions")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStudents.map((student) => (
                      <tr key={student.applicationId} className="border-t border-gray-100 hover:bg-gray-50">
                        <td className="p-3"><p className="font-medium">{student.studentName}</p><p className="text-xs text-gray-500">{student.applicationId}</p></td>
                        <td className="p-3">{student.phone}</td>
                        <td className="p-3">{student.village}</td>
                        <td className="p-3">{student.interestedClass} - {student.stream}</td>
                        <td className="p-3"><StatusBadge status={student.status} /></td>
                        <td className="p-3">
                          <select value={student.assignedTo || ""}
                            onChange={(e) => handleReassign(student.applicationId, e.target.value)}
                            className="text-xs border border-gray-300 rounded px-2 py-1">
                            {staffList?.filter((s) => s.role === "teacher").map((tch) => (
                              <option key={tch.staffId} value={tch.staffId}>{tch.nameEn}</option>
                            ))}
                          </select>
                        </td>
                        <td className="p-3">
                          <button onClick={() => updateMutation.mutate({ id: student.applicationId, status: "contacted" })}
                            className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 mr-1">{t("contacted")}</button>
                          <button onClick={() => handleArchive(student)}
                            className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded hover:bg-red-200">{t("archive")}</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {meetingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 no-print">
          <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
            <h3 className="font-semibold text-gray-900 mb-4">{t("fixMeeting")}</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t("date")}</label>
                <input type="date" value={meetingDate} onChange={(e) => setMeetingDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t("time")}</label>
                <select value={meetingTime} onChange={(e) => setMeetingTime(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">{t("selectTime")}</option>
                  {TIME_SLOTS.map((slot) => (<option key={slot} value={slot}>{slot}</option>))}
                </select>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setMeetingModal(null)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded text-sm hover:bg-gray-200">{t("cancel")}</button>
              <button onClick={handleFixMeeting} className="flex-1 bg-blue-800 text-white py-2 rounded text-sm hover:bg-blue-700">{t("save")}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
