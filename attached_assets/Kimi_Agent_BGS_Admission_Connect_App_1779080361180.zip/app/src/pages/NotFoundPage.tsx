import { Link } from "react-router-dom";
import { Home, AlertCircle } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function NotFoundPage() {
  const { t } = useLanguage();
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="text-center">
        <AlertCircle size={56} className="mx-auto text-gray-300 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 mb-2">404</h1>
        <p className="text-gray-500 mb-6">{t("noData")}</p>
        <Link to="/" className="inline-flex items-center gap-2 bg-blue-800 text-white rounded-lg px-6 py-3 hover:bg-blue-700 transition-colors">
          <Home size={18} />{t("backToHome")}
        </Link>
      </div>
    </div>
  );
}
