import { useState } from "react";
import { Navigate } from "react-router-dom";
import { BarChart3, Phone, MessageCircle, Calendar, Check, Archive } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import StatusBadge from "@/components/StatusBadge";
import { getWhatsAppUrl, getTelUrl, maskPhone, TIME_SLOTS } from "@/lib/utils";

const STATUS_COLUMNS = [
  { key: "new", label: "New", color: "bg-slate-50" },
  { key: "contacted", label: "Contacted", color: "bg-blue-50" },
  { key: "meeting_fixed", label: "Meeting Fixed", color: "bg-amber-50" },
  { key: "confirmed", label: "Confirmed", color: "bg-green-50" },
  { key: "archived", label: "Archived", color: "bg-red-50" },
] as const;

export default function TeacherDashboard() {
  const { isAuthenticated, hasRole, user } = useAuth();
  const { t } = useLanguage();
  const utils = trpc.useUtils();

  const { data: allApps, isLoading } = trpc.applications.list.useQuery();
  const updateMutation = trpc.applications.update.useMutation({
    onSuccess: () => utils.applications.list.invalidate(),
  });

  const [meetingModal, setMeetingModal] = useState<{
    appId: string;
    studentName: string;
    parentName: string;
    phone: string;
  } | null>(null);
  const [meetingDate, setMeetingDate] = useState("");
  const [meetingTime, setMeetingTime] = useState("");
  const [notesMap, setNotesMap] = useState<Record<string, string>>({});

  if (!isAuthenticated) return <Navigate to="/staff/login" replace />;
  if (!hasRole(["teacher"])) return <Navigate to="/" replace />;

  const myStudents = (allApps || []).filter((s) => s.assignedTo === user?.id);

  const stats = {
    total: myStudents.length,
    new: myStudents.filter((s) => s.status === "new").length,
    contacted: myStudents.filter((s) => s.status === "contacted").length,
    meeting_fixed: myStudents.filter((s) => s.status === "meeting_fixed").length,
    confirmed: myStudents.filter((s) => s.status === "confirmed").length,
    archived: myStudents.filter((s) => s.status === "archived").length,
  };

  const handleContact = (s: any) => {
    const msg = `Namaskara ${s.parentName}, BGS PU College. ${s.studentName}'s application ${s.applicationId} received. We will call you for campus visit. When are you free?`;
    window.open(getWhatsAppUrl(s.phone, msg), "_blank");
    updateMutation.mutate({ id: s.applicationId, status: "contacted" });
  };

  const handleFixMeeting = () => {
    if (!meetingModal || !meetingDate || !meetingTime) return;
    updateMutation.mutate({
      id: meetingModal.appId,
      status: "meeting_fixed",
      meetingDate,
      meetingTime,
    });
    const msg = `Namaskara ${meetingModal.parentName}, ${meetingModal.studentName} meeting: ${meetingDate} at ${meetingTime}. BGS PU College, Hanumanthpura. Reach 20 min early. Bring: SSLC Marks Card, TC, Aadhaar, 4 Photos, Caste Certificate. Call 9876500000.`;
    window.open(getWhatsAppUrl(meetingModal.phone, msg), "_blank");
    setMeetingModal(null);
    setMeetingDate("");
    setMeetingTime("");
  };

  const handleConfirm = (s: any) => {
    const msg = `Congratulations ${s.parentName}! ${s.studentName} CONFIRMED for ${s.interestedClass} ${s.stream} at BGS PU College. Welcome! Report at 8:30 AM.`;
    window.open(getWhatsAppUrl(s.phone, msg), "_blank");
    updateMutation.mutate({ id: s.applicationId, status: "confirmed" });
  };

  const handleArchive = (s: any) => {
    const msg = `Thank you for your interest in BGS PU College. Application ${s.applicationId} is now closed. Best wishes.`;
    window.open(getWhatsAppUrl(s.phone, msg), "_blank");
    updateMutation.mutate({ id: s.applicationId, status: "archived" });
  };

  const handleNotesSave = (appId: string) => {
    if (notesMap[appId]) {
      updateMutation.mutate({ id: appId, notes: notesMap[appId] });
    }
  };

  if (isLoading) return <div className="min-h-screen bg-gray-100 flex items-center justify-center"><p>{t("loading")}</p></div>;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-3 no-print">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BarChart3 size={20} className="text-blue-800" />
              <h1 className="font-bold text-gray-900">{t("welcome")}, {user?.nameEn}</h1>
            </div>
            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{t("teacher")}</span>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {[
              { label: t("totalApplications"), value: stats.total, color: "bg-gray-100 text-gray-800" },
              { label: t("new"), value: stats.new, color: "bg-slate-100 text-slate-800" },
              { label: t("contacted"), value: stats.contacted, color: "bg-blue-100 text-blue-800" },
              { label: t("meetingFixed"), value: stats.meeting_fixed, color: "bg-amber-100 text-amber-800" },
              { label: t("confirmed"), value: stats.confirmed, color: "bg-green-100 text-green-800" },
              { label: t("archived"), value: stats.archived, color: "bg-red-100 text-red-800" },
            ].map((stat, i) => (
              <div key={i} className={`${stat.color} rounded-lg p-2 text-center`}>
                <p className="text-lg font-bold">{stat.value}</p>
                <p className="text-[10px] font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-7xl mx-auto">
          {myStudents.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg"><p className="text-gray-500">{t("noStudentsAssigned")}</p></div>
          ) : (
            <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
              {STATUS_COLUMNS.map((col) => (
                <div key={col.key} className="snap-start flex-shrink-0 w-full sm:w-72 md:w-80">
                  <div className={`${col.color} rounded-lg border border-gray-200`}>
                    <div className="px-3 py-2 border-b border-gray-200 flex items-center justify-between">
                      <h3 className="font-semibold text-sm text-gray-800">{col.label}</h3>
                      <span className="bg-white text-xs font-medium px-2 py-0.5 rounded-full text-gray-600 border border-gray-200">
                        {myStudents.filter((s) => s.status === col.key).length}
                      </span>
                    </div>
                    <div className="p-2 space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto">
                      {myStudents.filter((s) => s.status === col.key).map((student) => (
                        <div key={student.applicationId} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="font-semibold text-gray-900 text-sm">{student.studentName}</h3>
                              <p className="text-xs text-gray-500">{student.interestedClass} - {student.stream}</p>
                            </div>
                            <StatusBadge status={student.status} />
                          </div>
                          <div className="space-y-1 text-xs text-gray-600 mb-3">
                            <p><span className="font-medium">{t("parentName")}:</span> {student.parentName}</p>
                            <p><span className="font-medium">{t("phoneNumber")}:</span> {maskPhone(student.phone)}</p>
                            <p><span className="font-medium">{t("village")}:</span> {student.village}</p>
                            <p className="text-gray-400">{student.applicationId}</p>
                          </div>
                          {(student.meetingDate || student.meetingTime) && (
                            <div className="bg-amber-50 border border-amber-200 rounded px-2 py-1 mb-3 text-xs">
                              <Calendar size={12} className="inline mr-1 text-amber-600" />
                              <span className="text-amber-800">{student.meetingDate} {student.meetingTime}</span>
                            </div>
                          )}
                          <div className="flex flex-wrap gap-1.5 mb-3">
                            <a href={getTelUrl(student.phone)} className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-1 rounded text-xs hover:bg-green-200">
                              <Phone size={12} />{t("call")}</a>
                            <button onClick={() => handleContact(student)} className="inline-flex items-center gap-1 bg-green-600 text-white px-2 py-1 rounded text-xs hover:bg-green-700">
                              <MessageCircle size={12} />{t("whatsapp")}</button>
                            {student.status !== "meeting_fixed" && student.status !== "confirmed" && (
                              <button onClick={() => setMeetingModal({ appId: student.applicationId, studentName: student.studentName, parentName: student.parentName, phone: student.phone })}
                                className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs hover:bg-amber-200">
                                <Calendar size={12} />{t("fixMeeting")}</button>
                            )}
                            {student.status === "meeting_fixed" && (
                              <button onClick={() => handleConfirm(student)} className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-1 rounded text-xs hover:bg-green-200">
                                <Check size={12} />{t("confirm")}</button>
                            )}
                            {student.status !== "archived" && (
                              <button onClick={() => handleArchive(student)} className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2 py-1 rounded text-xs hover:bg-red-200">
                                <Archive size={12} />{t("archive")}</button>
                            )}
                          </div>
                          <textarea defaultValue={student.notes || ""}
                            onChange={(e) => setNotesMap((prev) => ({ ...prev, [student.applicationId]: e.target.value }))}
                            onBlur={() => handleNotesSave(student.applicationId)}
                            placeholder={t("anyNotes")}
                            className="w-full text-xs border border-gray-200 rounded px-2 py-1 resize-none focus:outline-none focus:ring-1 focus:ring-blue-300" rows={2} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {meetingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 no-print">
          <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
            <h3 className="font-semibold text-gray-900 mb-4">{t("fixMeeting")}</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t("date")}</label>
                <input type="date" value={meetingDate} onChange={(e) => setMeetingDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t("time")}</label>
                <select value={meetingTime} onChange={(e) => setMeetingTime(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">{t("selectTime")}</option>
                  {TIME_SLOTS.map((slot) => (<option key={slot} value={slot}>{slot}</option>))}
                </select>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setMeetingModal(null)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded text-sm hover:bg-gray-200">{t("cancel")}</button>
              <button onClick={handleFixMeeting} className="flex-1 bg-blue-800 text-white py-2 rounded text-sm hover:bg-blue-700">{t("confirmMeeting")}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
