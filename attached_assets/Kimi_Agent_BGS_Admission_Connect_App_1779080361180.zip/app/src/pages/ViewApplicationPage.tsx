import { Link, useParams } from "react-router-dom";
import { ArrowLeft, FileText, Calendar, User, Phone, MapPin, GraduationCap, BookOpen, StickyNote } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { trpc } from "@/providers/trpc";
import StatusBadge from "@/components/StatusBadge";

export default function ViewApplicationPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();

  const { data: student } = trpc.applications.getById.useQuery(
    { id: id || "" },
    { enabled: !!id }
  );

  if (!student) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">{t("noApplicationFound")}</p>
          <Link to="/" className="text-blue-800 underline mt-2 inline-block">{t("backToHome")}</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <Link to="/" className="flex items-center gap-1 text-sm text-blue-800 mb-4 hover:underline">
          <ArrowLeft size={16} /> {t("backToHome")}
        </Link>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-5">
            <FileText size={24} className="text-blue-800" />
            <div>
              <h1 className="text-lg font-bold text-gray-900">{t("studentDetails")}</h1>
              <p className="text-xs text-gray-500">{student.applicationId}</p>
            </div>
          </div>

          <div className="space-y-4">
            {[
              { icon: User, label: t("studentName"), value: student.studentName },
              { icon: User, label: t("parentName"), value: student.parentName },
              { icon: Phone, label: t("phoneNumber"), value: student.phone, color: "text-green-600" },
              { icon: MapPin, label: t("village"), value: student.village, color: "text-red-500" },
              { icon: GraduationCap, label: t("interestedClass"), value: student.interestedClass },
              { icon: BookOpen, label: t("stream"), value: student.stream },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <item.icon size={18} className={item.color || "text-blue-800 flex-shrink-0"} />
                <div>
                  <p className="text-xs text-gray-500">{item.label}</p>
                  <p className="font-semibold text-gray-900">{item.value}</p>
                </div>
              </div>
            ))}

            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar size={18} className="text-blue-800 flex-shrink-0" />
              <div>
                <p className="text-xs text-gray-500">{t("status")}</p>
                <StatusBadge status={student.status} />
              </div>
            </div>

            {(student.meetingDate || student.meetingTime) && (
              <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                <Calendar size={18} className="text-amber-600 flex-shrink-0" />
                <div>
                  <p className="text-xs text-amber-700">{t("meetingDetails")}</p>
                  <p className="font-semibold text-amber-900">{student.meetingDate} {student.meetingTime}</p>
                </div>
              </div>
            )}

            {student.previousSchool && (
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <GraduationCap size={18} className="text-blue-800 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">{t("previousSchool")}</p>
                  <p className="font-semibold text-gray-900">{student.previousSchool}</p>
                </div>
              </div>
            )}

            {student.notes && (
              <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                <StickyNote size={18} className="text-yellow-600 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">{t("anyNotes")}</p>
                  <p className="text-sm text-gray-700">{student.notes}</p>
                </div>
              </div>
            )}

            <div className="text-xs text-gray-400 pt-2">
              {t("submittedOn")}: {new Date(student.createdAt).toLocaleDateString()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
