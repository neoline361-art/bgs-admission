import { Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./context/LanguageContext";
import { AuthProvider } from "./context/AuthContext";
import { TRPCProvider } from "./providers/trpc";
import LanguageToggle from "./components/LanguageToggle";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import LandingPage from "./pages/LandingPage";
import ApplyPage from "./pages/ApplyPage";
import SuccessPage from "./pages/SuccessPage";
import ViewApplicationPage from "./pages/ViewApplicationPage";
import StatusPage from "./pages/StatusPage";
import FeePage from "./pages/FeePage";
import ContactPage from "./pages/ContactPage";
import StaffLoginPage from "./pages/StaffLoginPage";
import TeacherDashboard from "./pages/TeacherDashboard";
import OfficeDashboard from "./pages/OfficeDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import NotFoundPage from "./pages/NotFoundPage";

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <TRPCProvider>
          <div className="min-h-screen flex flex-col bg-gray-50">
            <LanguageToggle />
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/apply" element={<ApplyPage />} />
                <Route path="/success/:id" element={<SuccessPage />} />
                <Route path="/application/:id" element={<ViewApplicationPage />} />
                <Route path="/status" element={<StatusPage />} />
                <Route path="/fees" element={<FeePage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/staff/login" element={<StaffLoginPage />} />
                <Route path="/teacher" element={<TeacherDashboard />} />
                <Route path="/office" element={<OfficeDashboard />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </TRPCProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;
