import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export function maskPhone(phone: string): string {
  if (!phone || phone.length < 5) return phone;
  return phone.slice(0, 5) + "X".repeat(phone.length - 5);
}

export function getWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = phone.replace(/\D/g, "");
  return `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export function getTelUrl(phone: string): string {
  return `tel:+91${phone.replace(/\D/g, "")}`;
}

export function exportToCSV(data: Record<string, any>[], filename: string) {
  if (!data || data.length === 0) return;
  const headers = Object.keys(data[0]);
  const csvRows = [
    headers.join(","),
    ...data.map((row) =>
      headers.map((h) => `"${String(row[h] ?? "").replace(/"/g, '""')}"`).join(",")
    ),
  ];
  const csv = csvRows.join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export const TIME_SLOTS = [
  "10:00", "10:30", "11:00", "11:30", "12:00",
  "14:00", "14:30", "15:00", "15:30", "16:00",
];

export function getStatusColor(status: string): string {
  switch (status) {
    case "new": return "bg-slate-100 text-slate-800 border-slate-200";
    case "contacted": return "bg-blue-100 text-blue-800 border-blue-200";
    case "meeting_fixed": return "bg-amber-100 text-amber-800 border-amber-200";
    case "confirmed": return "bg-green-100 text-green-800 border-green-200";
    case "archived": return "bg-red-100 text-red-800 border-red-200";
    default: return "bg-gray-100 text-gray-800";
  }
}
