import React, { createContext, useState, useContext, useCallback, useEffect } from "react";
import { trpc } from "@/providers/trpc";

interface User {
  id: string;
  nameEn: string;
  nameKn: string | null;
  role: string;
  phone: string | null;
}

const AuthContext = createContext<{
  user: User | null;
  isAuthenticated: boolean;
  login: (staffId: string, pin: string) => Promise<boolean>;
  logout: () => void;
  hasRole: (roles: string[]) => boolean;
}>({
  user: null,
  isAuthenticated: false,
  login: async () => false,
  logout: () => {},
  hasRole: () => false,
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const loginMutation = trpc.staff.login.useMutation();

  useEffect(() => {
    const stored = localStorage.getItem("bgs_auth");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.expiresAt && new Date(parsed.expiresAt) > new Date()) {
          setUser(parsed.user);
        } else {
          localStorage.removeItem("bgs_auth");
        }
      } catch {
        localStorage.removeItem("bgs_auth");
      }
    }
  }, []);

  const login = useCallback(
    async (staffId: string, pin: string) => {
      try {
        const result = await loginMutation.mutateAsync({ staffId, pin });
        if (result.success && result.user) {
          const userData = result.user as User;
          const expiresAt = new Date();
          expiresAt.setDate(expiresAt.getDate() + 7);
          localStorage.setItem(
            "bgs_auth",
            JSON.stringify({ user: userData, expiresAt: expiresAt.toISOString() })
          );
          setUser(userData);
          return true;
        }
        return false;
      } catch {
        return false;
      }
    },
    [loginMutation]
  );

  const logout = useCallback(() => {
    localStorage.removeItem("bgs_auth");
    setUser(null);
    window.location.href = "/";
  }, []);

  const hasRole = useCallback(
    (roles: string[]) => {
      if (!user) return false;
      return roles.includes(user.role);
    },
    [user]
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        hasRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
