import React, { createContext, useState, useContext, useCallback } from "react";
import { translations } from "../locales";

const LanguageContext = createContext<{
  language: "en" | "kn";
  toggleLanguage: () => void;
  t: (key: string) => string;
}>({
  language: "en",
  toggleLanguage: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<"en" | "kn">("en");

  const toggleLanguage = useCallback(() => {
    setLanguage((prev) => (prev === "en" ? "kn" : "en"));
  }, []);

  const t = useCallback(
    (key: string) => {
      return (translations[language] as any)?.[key] || (translations["en"] as any)?.[key] || key;
    },
    [language]
  );

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
