import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  int,
  mysqlEnum,
} from "drizzle-orm/mysql-core";

export const applications = mysqlTable("applications", {
  id: serial("id").primaryKey(),
  applicationId: varchar("application_id", { length: 50 }).notNull().unique(),
  studentName: varchar("student_name", { length: 255 }).notNull(),
  parentName: varchar("parent_name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  village: varchar("village", { length: 255 }).notNull(),
  interestedClass: varchar("interested_class", { length: 50 }).notNull(),
  stream: varchar("stream", { length: 50 }).notNull(),
  previousSchool: varchar("previous_school", { length: 255 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["new", "contacted", "meeting_fixed", "confirmed", "archived"])
    .notNull()
    .default("new"),
  assignedTo: varchar("assigned_to", { length: 50 }),
  meetingDate: varchar("meeting_date", { length: 20 }),
  meetingTime: varchar("meeting_time", { length: 20 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const staff = mysqlTable("staff", {
  id: serial("id").primaryKey(),
  staffId: varchar("staff_id", { length: 50 }).notNull().unique(),
  nameEn: varchar("name_en", { length: 255 }).notNull(),
  nameKn: varchar("name_kn", { length: 255 }),
  pin: varchar("pin", { length: 10 }).notNull(),
  role: mysqlEnum("role", ["teacher", "office", "admin"]).notNull(),
  phone: varchar("phone", { length: 20 }),
  active: int("active", { unsigned: true }).notNull().default(1),
});

export const settings = mysqlTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  staffId: varchar("staff_id", { length: 50 }),
  action: varchar("action", { length: 100 }).notNull(),
  details: text("details"),
  applicationId: varchar("application_id", { length: 50 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
