import { getDb } from "../api/queries/connection";
import { staff, settings } from "./schema";

const db = getDb();

async function seed() {
  console.log("Seeding database...");

  // Seed staff
  const existingStaff = await db.select().from(staff);
  if (existingStaff.length === 0) {
    await db.insert(staff).values([
      { staffId: "T001", nameEn: "Shri. Kumar", nameKn: "ಶ್ರೀ. ಕುಮಾರ್", pin: "1234", role: "teacher", phone: "9876500001", active: 1 },
      { staffId: "T002", nameEn: "Smt. Radha", nameKn: "ಸುಶ್ರೀ. ರಾಧಾ", pin: "5678", role: "teacher", phone: "9876500002", active: 1 },
      { staffId: "O001", nameEn: "Shri. Ananth", nameKn: "ಶ್ರೀ. ಅನಂತ್", pin: "9012", role: "office", phone: "9876500003", active: 1 },
      { staffId: "A001", nameEn: "Principal", nameKn: "ಪ್ರಿನ್ಸಿಪಾಲ್", pin: "0000", role: "admin", phone: "9876500000", active: 1 },
    ]);
    console.log("Staff seeded");
  }

  // Seed default settings
  const existingSettings = await db.select().from(settings);
  if (existingSettings.length === 0) {
    await db.insert(settings).values([
      { key: "collegeNameEn", value: "BGS PU College" },
      { key: "collegeNameKn", value: "BGS ಪು.ಪೂ. ಕಾಲೇಜು" },
      { key: "collegeAddress", value: "Hanumanthpura Gate, Shidlaghatta, Karnataka 562105" },
      { key: "collegeCode", value: "MC0118" },
      { key: "collegePhone", value: "9876500000" },
      { key: "collegeWhatsapp", value: "9876500000" },
      { key: "officeHours", value: "9:00 AM - 4:30 PM" },
      { key: "admissionFee", value: "500" },
      { key: "tuitionFee", value: "12000" },
      { key: "labFee", value: "2000" },
      { key: "libraryFee", value: "500" },
      { key: "examFee", value: "1500" },
      { key: "sportsFee", value: "500" },
      { key: "developmentFee", value: "1000" },
      { key: "streams", value: "Science,Commerce" },
      { key: "classes", value: "1st PUC,2nd PUC" },
    ]);
    console.log("Settings seeded");
  }

  console.log("Seed complete");
}

seed().catch(console.error);
